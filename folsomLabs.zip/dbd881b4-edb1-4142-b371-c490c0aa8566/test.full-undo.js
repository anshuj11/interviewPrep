var TravelGraph = require('./traveller');
var assert = require('chai').assert;

describe('TestUndoRedoStack', function() {
    var tg = new TravelGraph();

    beforeEach(function() {
        tg = new TravelGraph();
    });

    describe('#undoChange(), #redoChange', function() {
        it('should undo multiple actions', function() {
            let p1 = tg.addItem('P1', 50, []);
            let p2 = tg.addItem('P2', 100, ['P1']);

            tg.deleteItem(p2);
            tg.editItem(p1, 'P1 Edited');

            tg.undoChange(); // undo edit

            p1 = tg.getItem('P1');
            assert.equal(p1.name, 'P1');
            assert.equal(tg.items.length, 1);

            assert.throws(() => tg.getItem('P1 Edited'), ReferenceError);

            tg.undoChange(); // undo delete

            p1 = tg.getItem('P1');
            p2 = tg.getItem('P2');
            assert.deepStrictEqual(tg.items, [p1, p2]);
            assert.deepStrictEqual(p2.destinations, [p1]);
        });

        it('should undo multiple actions after delete', function() {
            let p1 = tg.addItem('P1', 50, []);
            let p2 = tg.addItem('P2', 100, ['P1']);

            tg.deleteItem(p2);

            tg.undoChange(); // undo delete

            p1 = tg.getItem('P1');
            p2 = tg.getItem('P2');
            assert.equal(p2.name, 'P2');
            assert.deepStrictEqual(p2.destinations, [p1]);
            assert.equal(tg.items.length, 2);

            tg.undoChange(); // undo add

            p1 = tg.getItem('P1');
            assert.equal(tg.items.length, 1);
            assert.deepStrictEqual(tg.items[0], p1);
        });

        it('should undo with proper destination references', function() {
            let p1 = tg.addItem('P1', 50, []);
            let p2 = tg.addItem('P2', 100, ['P1']);

            tg.deleteItem(p2);
            tg.undoChange(); // undo delete

            p1 = tg.getItem('P1');
            p2 = tg.getItem('P2');

            tg.editItem(p1, 'P1 Edited');

            // Check that proper p1 node is referenced and updated
            const p1Destination = tg.getItem('P2').destinations[0];
            assert.equal(p1Destination.name, 'P1 Edited');
        });

        it('can undo and redo an edit', function() {
            let p1 = tg.addItem('P1', 50, []);
            let p2 = tg.addItem('P2', 100, ['P1']);
            tg.editItem(p1, p1.name, p1.price, ['P2']);

            tg.undoChange(); // undo edit
            p1 = tg.getItem('P1');
            p2 = tg.getItem('P2');
            assert.deepStrictEqual(p1.destinations, []);

            tg.redoChange(); // redo edit

            p1 = tg.getItem('P1');
            p2 = tg.getItem('P2');
            assert.deepStrictEqual(p1.destinations, [p2]);
        });

        it('can undo and redo a delete', function() {
            var p1 = tg.addItem('P1', 50, []);
            var p2 = tg.addItem('P2', 100, ['P1']);

            tg.deleteItem(p2);

            tg.undoChange();

            p1 = tg.getItem('P1');
            p2 = tg.getItem('P2');
            assert.equal(p2.name, 'P2');
            assert.deepStrictEqual(p2.destinations, [p1]);
            assert.equal(tg.items.length, 2);

            tg.redoChange();

            p1 = tg.getItem('P1');
            assert.equal(tg.items.length, 1);
            assert.deepStrictEqual(tg.items[0], p1);
        });

        it('should clear potential redos after a new action', function() {
            var p1 = tg.addItem('P1', 50, []);
            var p2 = tg.addItem('P2', 100, ['P1']);

            tg.undoChange(); // undo P2 add

            p1 = tg.getItem('P1');

            var p3 = tg.addItem('P3', 150, ['P1']);
            assert.throws(() => tg.redoChange(), Error);
        });

        it('can undo first add', function () {
            var p1 = tg.addItem('P1', 50, []);

            tg.undoChange(); // undo P1 add

            assert.equal(tg.items.length, 0);
        });

        it('multiple undos and redos', function () {
            var p1 = tg.addItem('P1', 50, []);
            var p2 = tg.addItem('P2', 100, ['P1']);

            tg.editItem(p1, 'P1 Edited');
            tg.editItem(p2, 'P2 Edited');

            tg.undoChange();  // undo edit p2
            p1 = tg.getItem('P1 Edited');
            p2 = tg.getItem('P2');

            assert.equal(p2.name, 'P2');
            assert.deepStrictEqual(tg.items, [p1, p2]);

            tg.undoChange();  // undo edit p1
            p1 = tg.getItem('P1');
            p2 = tg.getItem('P2');

            assert.equal(p1.name, 'P1');
            assert.deepStrictEqual(p2.destinations, [p1]);
            assert.deepStrictEqual(tg.items, [p1, p2]);

            tg.redoChange();  // redo edit p1
            p1 = tg.getItem('P1 Edited');
            p2 = tg.getItem('P2');

            assert.equal(p1.name, 'P1 Edited');
            assert.deepStrictEqual(p2.destinations, [p1]);
            assert.deepStrictEqual(tg.items, [p1, p2]);

            tg.redoChange();  // redo edit p2
            p1 = tg.getItem('P1 Edited');
            p2 = tg.getItem('P2 Edited');

            assert.equal(p2.name, 'P2 Edited');
            assert.deepStrictEqual(tg.items, [p1, p2]);
        });

        it('can undo after redo', function () {
            var p1 = tg.addItem('P1', 50, []);
            var p2 = tg.addItem('P2', 100, ['P1']);

            tg.editItem(p2, 'P2 Edited');

            tg.undoChange();  // undo edit p2
            p1 = tg.getItem('P1');
            p2 = tg.getItem('P2');

            assert.equal(p1.name, 'P1');
            assert.equal(p2.name, 'P2');
            assert.deepStrictEqual(tg.items, [p1, p2]);

            tg.redoChange();  // redo edit p2
            p1 = tg.getItem('P1');
            p2 = tg.getItem('P2 Edited');

            assert.equal(p1.name, 'P1');
            assert.equal(p2.name, 'P2 Edited');
            assert.deepStrictEqual(tg.items, [p1, p2]);

            tg.undoChange();  // undo edit p2
            p1 = tg.getItem('P1');
            p2 = tg.getItem('P2');

            assert.equal(p1.name, 'P1');
            assert.equal(p2.name, 'P2');
            assert.deepStrictEqual(tg.items, [p1, p2]);
        });

        it('can redo after failed undo', function () {
            var p1 = tg.addItem('P1', 50, []);

            tg.undoChange(); // undo P1 add
            assert.equal(tg.items.length, 0);

            // can't undo past travel graph construction
            assert.throws(() => tg.undoChange(), Error);

            tg.redoChange(); // redo P1 add
            var p1_redo = tg.getItem('P1');
            assert.deepStrictEqual(p1_redo, p1);
        });
    });
});
