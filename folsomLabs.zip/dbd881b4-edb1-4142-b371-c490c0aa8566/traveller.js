var NotImplementedError = require("./errors").NotImplementedError;
var action_stack = [];
class TravelGraph {
  constructor(items = []) {
    this.items = items;
  }

  // log current graph nodes to the console
  display(label = "–") {
    console.log(`–– ${(label + " ").padEnd(46, "–")}`);
    for (const { name, price, destinations } of this.items) {
      const destList = destinations.map(d => d.name).join(", ");
      console.log(`${name} (\$${price}) => [${destList}]`);
    }
    console.log("=================================================");
  }

  getItem(name, items = this.items) {
    for (const item of items) {
      if (item.name === name) return item;
    }
    throw new ReferenceError("Item not found");
  }

  // add a new location item
  addItem(name, price, destinationNames) {
    const destinations = destinationNames.map(name => this.getItem(name));

    const item = { name, price, destinations };
    this.items.push(item);
    // console.log("this.items Post Undo: ", this.items);
    action_stack.push({ type: "Add", value: item });
    return item;
  }

  // change a given location item's properties
  editItem(item, name = null, price = null, destinationNames = null) {
    const destinations = destinationNames.map(name => this.getItem(name));
    const new_item = { name, price, destinations };
    action_stack.push({ type: "Change", value: item, new_value: new_item });
    if (name != null) {
      item.name = name;
    }
    if (price != null) {
      item.price = price;
    }
    if (destinationNames != null) {
      item.destinations = destinationNames.map(name => this.getItem(name));
    }
    return item;
  }

  // delete a location item from list
  deleteItem(item) {
    let indexToDelete = -1;
    this.items.forEach((el, i) => {
      if (el.name === item.name) {
        indexToDelete = i;
      }
    });
    if (indexToDelete === -1) throw new ReferenceError();

    this.items = this.items.filter(el => el.name !== item.name);

    for (let i = 0; i < this.items.length; i++) {
      let tempDest = [];
      let originsWithThisDest = [];
      for (let j = 0; j < this.items[i].destinations.length; j++) {
        if (this.items[i].destinations[j].name !== item.name) {
          tempDest.push(this.items[i].destinations[j]);
        } else {
          originsWithThisDest.push(this.items[i].name);
        }
      }
      this.items[i].destinations = tempDest;
      action_stack.push({
        type: "Delete",
        name: item.name,
        price: item.price,
        destinationNames: item.destinations.map(d => d.name),
        originsWithThisDest: originsWithThisDest
      });
    }
  }

  // undo a change
  undoChange() {
    //throw new NotImplementedError();

    let action = action_stack.pop();
    if (action.type === "Add") {
      this.deleteItem(action.item);
      action_stack.pop();
    } else if (action.type === "Delete") {
      console.log("Undoing a delete");
      //console.log("Action.value:  ", action.value);
      // let destinationNames = action.value.destinations.map(d => d.name);
      console.log("Destination Name: ", action.destinationNames);
      console.log("Origin Name: ", action.originsWithThisDest);
      this.addItem(action.name, action.price, action.destinationNames);
      let item = this.getItem(action.name);
      for (let m = 0; m < this.items.length; m++) {
        if (action.originsWithThisDest.includes(this.items[m].name))
          this.items[m].destinations.push(item);
      }

      //   let my_item = this.items.pop();
      //   this.items =
      //     this.items.slice(0, action.position) +
      //     my_item +
      //     this.items.slice(action.position);
      this.items = this.items.sort((a, b) => a.name - b.name);
      console.log("After undo: this.items: ", this.items);
      action_stack.pop();
    } else {
      // } (action.type === "Change") {
      let destinationNames = action.value.destinations.map(d => d.name);
      this.editItem(
        action.new_value,
        (name = action.value.name),
        action.value.price,
        destinationNames
      );
      action_stack.pop();
    }
  }

  // redo a change
  redoChange() {
    throw new NotImplementedError();
  }

  // clone all items in the current graph
  cloneItems(items = this.items || []) {}

  /**
   * Part 3: Graph Traversal (Optional) methods below
   */
  // return list of all destinations reachable from A
  allDestinations(itemA) {
    throw new NotImplementedError();
  }

  // return list of all origins which can reach A
  allOrigins(itemA) {
    throw new NotImplementedError();
  }

  // return whether or not valid path exists from A to B
  validPath(itemA, itemB) {
    throw new NotImplementedError();
  }

  // return list of locations on cheapest path to get from A to B
  cheapestPath(itemA, itemB) {
    throw new NotImplementedError();
  }

  // serialize list to json string
  serialize() {}

  // deserialize json string to list
  deserialize(json) {}

  static sampleData() {
    const items = [
      { name: "Fresno", price: 199 },
      { name: "Toledo", price: 299 }
    ];

    Object.assign(items[0], {
      destinations: [items[1]]
    });

    Object.assign(items[1], {
      destinations: [items[0]]
    });

    return items;
  }
}

if (require.main === module) {
  var tg = new TravelGraph(TravelGraph.sampleData());
  tg.display("Initial Travel Graph");

  const modesto = tg.addItem("Modesto", 99, ["Fresno", "Toledo"]);
  tg.display("Add Modesto"); // Modesto should show up w/ Two Destinations

  const fresno = tg.getItem("Fresno");
  tg.deleteItem(fresno);
  tg.display("Delete Fresno"); // Fresno should be removed from the list

  tg.undoChange();
  tg.display("Undo Fresno Delete"); // Fresno should be fully back in the list
}

module.exports = TravelGraph;
