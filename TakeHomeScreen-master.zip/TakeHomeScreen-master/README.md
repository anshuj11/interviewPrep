# TakeHomeScreen
## A repository for technical front end take home screen

Write a single page JavaScript application that allows users to search through Github repositories via keyword.

While this is a relatively open-ended exercise, please abide by the following rules and requirements...

1. Use the Github GraphQL API
1. Write your app using React.js using latest design patterns such as hooks
    1. Use any supporting libraries you see fit
1. We want to respect your time, so you should not spend more than two (2) hours on this task
1. Some files have been created for you in advance - modify them as you see fit
1. Search results should display as a list. Each list item should display the repository's name and owner
1. When a result is clicked, please display the repository's language, followers, url and description
1. UI presentation and search UX is up to you
1. Build for the latest desktop version of Chrome only
    1. Bonus points for noting anything that has potential for cross browser issues
1. In a SOLUTION.md file, please explain where you would take this feature post-submission.
    1. i.e. What refactors, changes to code organization, or enhancements you would make if you had more time. 

In this exercise we're most interested in your ability to follow directions and that your engineering solution includes a simple and clean implementation.
