Rails.application.routes.draw do
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  root "tasks#index"

  resources :tasks, only: %i[index show new create update]
  resources :kinds, except: %i[show destroy]
end
