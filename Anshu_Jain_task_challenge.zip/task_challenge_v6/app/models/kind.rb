class Kind < ApplicationRecord
  def min_size
    20
  end

  def color
     "blue" 
  end
  has_many :tasks
  validates :name, presence: true, uniqueness: true, length: {minimum: 5 }
end
