class Task < ApplicationRecord
  belongs_to :kind

  validates :name, presence: true
  validates :category, presence: true
  #validates :kind, presence: true
  validates :description, presence: true
 # validates :delivery_at

  # missing category here with: development, backlog, review, administrative


#   The task implementation has been started but it's not completed. We need to be able to add a task, view a task, and edit a task. We don't want to destroy tasks though.
# The task should have at least:
#   * a name (required)
#   * a category: this must be a dropdown list, the fixed values can be any of "development, backlog, review, administrative"
#   * a delivery date & time
#   * a description (required)
#   * a kind: this must be another dropdown list which uses the already built kind model. (required) Note that if a kind is inactive I should not be able to select it for a new or when editing a task, but if it's already attached I should still see it.

end
