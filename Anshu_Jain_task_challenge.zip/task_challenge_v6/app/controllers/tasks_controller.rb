class TasksController < ApplicationController
  def index
    #debugger;
    @tasks = Task.all
    if params[:search]
      @tasks = @tasks.select do |task|
        task.name.include?(params[:search])  || task.description.include?(params[:search])
      end
    end
    
  end

  def show
    @task = Task.find(params[:id])
    if @task
      render :show
    else
      redirect_to tasks_url
    end  
  end

  def create
    
    kind = Kind.find(task_params[:kind].to_i)
    task = Task.new(name: task_params[:name], 
                    category: task_params[:category], 
                    delivery_at: task_params[:delivery_at], 
                    description: task_params[:description])
    task.kind = kind              
    if(task.save!)
      redirect_to tasks_url
    else
      @kind = Kind.all
      render :new
    end
  end

  def new
    @kind = Kind.all
  end

  private
  def task_params
    params.require(:task).permit(:name, :category, :delivery_at, :description, :kind, :search)
  end
end
