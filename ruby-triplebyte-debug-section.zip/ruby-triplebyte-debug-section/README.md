# Web crawler

### Setup

`bundle install` should be sufficient.

To run the starting test cases and check that everything's working:

    bundle exec rspec specs/already_passing/

To run a specific test case:

    bundle exec rspec specs/failing_tests/failing_test_1_spec.rb
