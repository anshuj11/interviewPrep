import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import styles from '../styles/podcast-list-item';

function PodcastListItem(props) {
  const {
    title,
    slug,
    image = [],
    'itunes:image': itunesBackupImages = [],
  } = props;
  let imgSrc = null;
  let imgAlt = null;
  if (image[0]) {
    imgSrc = image[0].url;
    imgAlt = image[0].title;
  } else if (itunesBackupImages[0]) {
    const itunesBackupImage = itunesBackupImages[0].$;
    imgSrc = itunesBackupImage ? itunesBackupImage.href : null;
    imgAlt = title;
  }

  return (
    <li className={styles.podcastListItem} >
      <Link className={styles.itemLink} to={`/${slug}`} data-title={title}>
        <img alt={imgAlt} src={imgSrc} className={styles.itemImg} />
      </Link>
    </li>
  );
}

PodcastListItem.propTypes = {
  title: PropTypes.array,
  slug: PropTypes.string,
  image: PropTypes.array,
  'itunes:image': PropTypes.array,
};

export default PodcastListItem;
