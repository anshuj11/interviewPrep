import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as podcastActions from '../action-creators/podcasts';
import styles from '../styles/podcast-episode-list';

function PodcastEpisodeList(props) {
  const {
    title: [podcastTitle = ''] = [],
    item: episodes = [],
    match,
    loadPodcastEpisode,
  } = props;

  const formattedEps = episodes.map(({ enclosure, title: [title], guid: [guid] }) => ({
    podcastTitle,
    title,
    src: enclosure[0].$.url,
    podcastId: match.params.podcastId,
    guid: guid._ || title,
  }));

  return (
    <div className={styles.episodeListContainer}>
      <h1>{podcastTitle}</h1>
      <ul className={styles.episodeList}>
        {
          formattedEps.map((ep) => (
            <li
              key={ep.guid} className={styles.episodeListItem} alt={ep.title}
              onClick={() => loadPodcastEpisode(ep)}
            >
              <div>
                {ep.title}
              </div>
            </li>
          ))
        }
      </ul>
    </div>
  );
}
PodcastEpisodeList.propTypes = {
  loadPodcastEpisode: PropTypes.func.isRequired,
  title: PropTypes.arrayOf(PropTypes.string),
  item: PropTypes.arrayOf(PropTypes.object),
  match: PropTypes.object.isRequired,
};

const mapStateToProps = (state, ownProps) => state.podcasts[ownProps.match.params.podcastId] || {};
const mapDispatchToProps = (dispatch) => bindActionCreators(podcastActions, dispatch);

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(PodcastEpisodeList);
