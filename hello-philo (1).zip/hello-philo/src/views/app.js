import React from 'react';
import { Switch, Route } from 'react-router-dom';
import styles from '../styles/app';
import Sidebar from './sidebar';
import PodcastList from './podcast-list';
import PodcastEpisodeList from './podcast-episode-list';
import Player from './player';

function App() {
  return (
    <div className={styles.layout}>
      <div className={styles.topLayout}>
        <Sidebar />
        <div className={styles.main}>
          <Switch>
            <Route exact path="/" component={PodcastList} />
            <Route path="/:podcastId" component={PodcastEpisodeList} />
          </Switch>
        </div>
      </div>
      <Player />
    </div>
  );
}

export default App;
