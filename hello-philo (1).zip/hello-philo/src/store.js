import { applyMiddleware, createStore } from 'redux';
import { composeWithDevTools } from 'redux-devtools-extension/developmentOnly';
import createLogger from 'redux-logger';
import thunk from 'redux-thunk';
import rootReducer from './reducers';

const logger = createLogger();

/* global __DEV__ */
export default function configureStore(initialState = {}, debug = __DEV__) {
  const middlewares = [thunk];
  if (debug) {
    middlewares.push(logger);
  }
  const createStoreWithMiddleware = composeWithDevTools(applyMiddleware(...middlewares));

  const store = (createStoreWithMiddleware)(createStore)(rootReducer, initialState);

  if (module.hot) {
    module.hot.accept('./reducers', () => {
      // eslint-disable-next-line
      const nextRootReducer = require('./reducers/index').default;
      store.replaceReducer(nextRootReducer);
    });
  }

  return store;
}
